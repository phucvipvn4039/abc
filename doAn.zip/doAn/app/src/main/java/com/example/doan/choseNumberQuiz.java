package com.example.doan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class choseNumberQuiz extends AppCompatActivity {
    Spinner Spin;
    int vitri;
    Button btNext, btbBack;
    String Arr[] = {"5", "6", "7", "8", "9", "10"}; //Tạo mảng chứa các phép toán


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_number_quiz);
        Spin = findViewById(R.id.spinnerSoCau);
        btNext = (Button) findViewById(R.id.BtnNext);
        btbBack= (Button) findViewById((R.id.Btback));
        taoSpin();
        buttonBackvsNext();
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(choseNumberQuiz.this,quiz.class);
                Bundle bundle= new Bundle();
                bundle.putInt("soCau",vitri);
                i.putExtra("CauHoi",bundle);
                startActivity(i);
            }
        });

    }

    public void taoSpin() {
        //Gán mảng Arr (data source) vào Adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, Arr);
//Thiết lập cách hiển thị dữ liệu trong spinner
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
//Thiết lập adapter cho spinner
        Spin.setAdapter(adapter);
//Bắt sự kiện khi lựa chọn cho spinner
        Spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               vitri= Integer.parseInt(parent.getItemAtPosition(position)+"");
               Toast.makeText(choseNumberQuiz.this,vitri+"",Toast.LENGTH_LONG).show();
                Log.d("check", vitri+"");


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                vitri = -1;
            }
        });
    }



    public void buttonBackvsNext()
    {


        btbBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
////        btNext.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                Intent intent = new Intent(choseNumberQuiz.this, MainActivity.class);
////            }
////        });
////    }
    }
}