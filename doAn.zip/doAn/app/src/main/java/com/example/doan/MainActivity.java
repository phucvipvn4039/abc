package com.example.doan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class
MainActivity extends AppCompatActivity  {
    Button bt1, bt2, bt3, bt4, btNext, btbBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1 = (Button) findViewById(R.id.bteasy);
        bt2 = (Button) findViewById(R.id.btnormal);
        bt3 = (Button) findViewById(R.id.bthard);
    intoAotherPage();

    }
         //bt1 intent
        public void intoAotherPage()
    {
            bt1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //dùng intent de di chuyen giua cac activity
                    Intent intent = new Intent(MainActivity.this, choseNumberQuiz.class);
                    startActivity(intent);
                }
            });
            //bt2 intent
            bt2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, choseNumberQuiz.class);
                    startActivity(intent);
                }
            });
            //bt3 intent
            bt3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, choseNumberQuiz.class);
                    startActivity(intent);
                }
            });



        }
}