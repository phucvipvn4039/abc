
package com.example.doan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class quiz  extends AppCompatActivity {
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        tv=findViewById(R.id.gioiHan);
        int n=0;
        Intent i=getIntent();
        Bundle bundle=i.getBundleExtra("CauHoi");
        n=bundle.getInt("soCau");
        tv.setText(n+"");

    }
}